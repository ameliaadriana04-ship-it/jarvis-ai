# JARVIS AI untuk Android — Paket fitur lengkap (starter)

## Fitur di proyek
- Antarmuka gelap futuristik dan animasi orb
- Chat AI online melalui backend HTTPS
- Speech-to-text bahasa Indonesia dan Text-to-Speech
- Tombol bicara sekali dan mode "Hey Jarvis" ketika aplikasi terbuka
- Perintah lokal untuk membuka WhatsApp, YouTube, kamera, dan Pengaturan
- Perintah alarm yang membuka layar konfirmasi aplikasi Jam Android
- Perintah pengingat yang membuka aplikasi Kalender untuk mengisi jadwal

## Penting
Ini adalah source code proyek Android Studio, bukan APK terkompilasi. Build APK memerlukan Android Studio/Android SDK dan konfigurasi backend. Perintah suara bisa berbeda tergantung layanan pengenalan suara pada perangkat.

## Build aplikasi
1. Ekstrak ZIP.
2. Buka folder `JARVIS_AI_Android` di Android Studio.
3. Tunggu Gradle Sync.
4. Sambungkan HP Android atau pilih emulator.
5. Klik Run untuk uji coba, atau gunakan menu Build untuk membuat APK.

## Mengaktifkan AI online
1. Deploy folder `backend` ke hosting Node.js yang menyediakan HTTPS.
2. Set environment variable `AI_API_KEY` pada server. Opsional: `AI_API_URL` dan `AI_MODEL`.
3. Jalankan `npm install` lalu `npm start` di lingkungan Node.js, atau ikuti panduan deploy hosting.
4. Edit `app/src/main/java/com/example/jarvisai/MainActivity.kt`.
5. Ganti `https://YOUR-BACKEND-URL.example/chat` dengan URL HTTPS backend milikmu.
6. Jangan menaruh API key di kode Android atau membagikannya di chat.

## Contoh perintah
- "Hey Jarvis, buka WhatsApp"
- "Buka YouTube"
- "Buka kamera"
- "Buka pengaturan"
- "Pasang alarm jam 07:00" (akan membuka layar konfirmasi Jam)
- "Pengingat bayar tagihan" (akan membuka Kalender; tanggal/waktu diisi pengguna)
- Pertanyaan umum akan dikirim ke backend AI setelah backend dikonfigurasi.

## Batasan dan privasi
- Mode wake-word pada starter ini bukan mesin wake-word khusus; ia memakai SpeechRecognizer Android dan hanya dimaksudkan berjalan saat aplikasi terbuka. Android/layanan speech bisa menghentikannya.
- Aksi sistem dibatasi oleh Android; alarm dan kalender memerlukan konfirmasi pengguna.
- Buka aplikasi menggunakan intent Android dan hanya untuk aplikasi yang terpasang.
- Gunakan backend HTTPS, lindungi API key, tambahkan autentikasi/rate limiting sebelum pemakaian publik, dan siapkan kebijakan privasi.
