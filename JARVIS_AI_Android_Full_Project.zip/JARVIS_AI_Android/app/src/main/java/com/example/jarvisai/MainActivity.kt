package com.example.jarvisai

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.LinearInterpolator
import android.view.animation.RotateAnimation
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var conversation: TextView
    private lateinit var input: EditText
    private lateinit var micButton: Button
    private lateinit var handsFreeButton: Button
    private lateinit var orb: TextView
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var handsFree = false
    private var waitingForWakeWord = false
    private val executor = Executors.newSingleThreadExecutor()

    // Ganti dengan URL HTTPS backend milikmu. Jangan simpan API key di aplikasi.
    private val backendUrl = "https://YOUR-BACKEND-URL.example/chat"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 10, 24)
        window.navigationBarColor = Color.rgb(5, 10, 24)
        tts = TextToSpeech(this, this)
        buildInterface()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(22, 24, 22, 16)
            setBackgroundColor(Color.rgb(5, 10, 24))
        }
        root.addView(TextView(this).apply {
            text = "J.A.R.V.I.S"; textSize = 30f; letterSpacing = 0.18f
            setTextColor(Color.rgb(60, 210, 255)); gravity = Gravity.CENTER
        }, matchWrap())
        root.addView(TextView(this).apply {
            text = "PERSONAL AI ASSISTANT"; textSize = 11f; letterSpacing = 0.18f
            setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }, matchWrap())

        status = TextView(this).apply {
            text = "● SYSTEM READY"; textSize = 13f
            setTextColor(Color.rgb(75, 230, 170)); gravity = Gravity.CENTER
            setPadding(0, 14, 0, 8)
        }
        root.addView(status, matchWrap())

        orb = TextView(this).apply {
            text = "◉"; textSize = 82f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(35, 190, 255)); setPadding(0, 0, 0, 8)
        }
        root.addView(orb, matchWrap())

        val scroll = ScrollView(this)
        conversation = TextView(this).apply {
            text = "JARVIS: Sistem siap. Aku dapat membantu membuka aplikasi, mengatur alarm, membuat pengingat kalender, atau menjawab pertanyaan melalui AI online."
            textSize = 15f; setTextColor(Color.WHITE); setPadding(12, 12, 12, 12)
        }
        scroll.addView(conversation)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        input = EditText(this).apply {
            hint = "Tulis pesan untuk JARVIS..."
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); textSize = 15f
            minLines = 1; maxLines = 3; setPadding(12, 8, 12, 8)
        }
        root.addView(input, matchWrap())
        root.addView(Button(this).apply {
            text = "KIRIM PESAN"
            setOnClickListener {
                val message = input.text.toString().trim()
                if (message.isNotEmpty()) { input.setText(""); askJarvis(message) }
            }
        }, matchWrap())

        micButton = Button(this).apply {
            text = "🎙  BICARA SEKARANG"
            setOnClickListener { startSingleListening() }
        }
        root.addView(micButton, matchWrap())

        handsFreeButton = Button(this).apply {
            text = "AKTIFKAN MODE HEY JARVIS"
            setOnClickListener { if (handsFree) stopHandsFree() else startHandsFree() }
        }
        root.addView(handsFreeButton, matchWrap())

        root.addView(TextView(this).apply {
            text = "Perintah lokal: buka WhatsApp/YouTube/kamera • alarm jam 07:00 • pengingat ..."
            textSize = 10f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(0, 8, 0, 0)
        }, matchWrap())
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun appendLine(line: String) {
        runOnUiThread { conversation.append("\\n\\n$line") }
    }

    private fun animateOrb(active: Boolean) {
        runOnUiThread {
            orb.clearAnimation()
            if (active) {
                val rotate = RotateAnimation(0f, 360f, 1, .5f, 1, .5f).apply {
                    duration = 5000; repeatCount = AlphaAnimation.INFINITE
                    interpolator = LinearInterpolator()
                }
                orb.startAnimation(rotate)
            }
        }
    }

    private fun startSingleListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Pengenalan suara tidak tersedia di perangkat ini.", Toast.LENGTH_LONG).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100); return
        }
        waitingForWakeWord = false
        ensureRecognizer()
        status.text = "● LISTENING"; animateOrb(true)
        speechRecognizer?.startListening(speechIntent())
    }

    private fun startHandsFree() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Pengenalan suara tidak tersedia.", Toast.LENGTH_LONG).show(); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100); return
        }
        handsFree = true; waitingForWakeWord = true
        handsFreeButton.text = "MATIKAN MODE HEY JARVIS"
        status.text = "● MENUNGGU KATA PEMICU"; animateOrb(true)
        appendLine("JARVIS: Mode hands-free aktif. Ucapkan 'Hey Jarvis' saat aplikasi tetap terbuka.")
        ensureRecognizer(); startListeningSafely()
    }

    private fun stopHandsFree() {
        handsFree = false; waitingForWakeWord = false
        handsFreeButton.text = "AKTIFKAN MODE HEY JARVIS"
        status.text = "● READY"; animateOrb(false)
        try { speechRecognizer?.cancel() } catch (_: Exception) {}
    }

    private fun ensureRecognizer() {
        if (speechRecognizer != null) return
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                runOnUiThread { status.text = if (handsFree && waitingForWakeWord) "● MENUNGGU: HEY JARVIS" else "● MENDENGARKAN" }
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { runOnUiThread { status.text = "● MEMPROSES SUARA" } }
            override fun onError(error: Int) {
                if (handsFree) status.postDelayed({ startListeningSafely() }, 800)
                else { status.text = "● READY"; animateOrb(false) }
            }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                if (spoken.isNotBlank()) {
                    if (handsFree && waitingForWakeWord) {
                        if (spoken.lowercase(Locale.ROOT).contains("hey jarvis") || spoken.lowercase(Locale.ROOT).contains("hei jarvis")) {
                            waitingForWakeWord = false
                            val command = spoken.replace(Regex("(?i)hey\\s*jarvis|hei\\s*jarvis"), "").trim()
                            if (command.isNotBlank()) askJarvis(command) else {
                                appendLine("JARVIS: Ya, saya mendengarkan."); speak("Ya, saya mendengarkan.")
                            }
                            status.postDelayed({
                                if (handsFree) { waitingForWakeWord = true; startListeningSafely() }
                            }, 1400)
                        } else startListeningSafely()
                    } else {
                        askJarvis(spoken)
                        if (handsFree) {
                            waitingForWakeWord = true
                            status.postDelayed({ startListeningSafely() }, 1800)
                        }
                    }
                } else if (handsFree) startListeningSafely()
                else { status.text = "● READY"; animateOrb(false) }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun speechIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
    }

    private fun startListeningSafely() {
        if (!handsFree || isFinishing) return
        try { speechRecognizer?.startListening(speechIntent()) }
        catch (_: Exception) { status.postDelayed({ if (handsFree) startListeningSafely() }, 1000) }
    }

    private fun askJarvis(message: String) {
        appendLine("KAMU: $message")
        if (runLocalCommand(message)) return
        status.text = "● THINKING"; animateOrb(true)
        executor.execute {
            try {
                val conn = (URL(backendUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                conn.outputStream.use { it.write(JSONObject().put("message", message).toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val obj = JSONObject(body)
                val answer = obj.optString("reply", obj.optString("error", "Maaf, belum ada jawaban dari server."))
                runOnUiThread {
                    appendLine("JARVIS: $answer"); status.text = "● ONLINE • READY"
                    animateOrb(false); speak(answer)
                }
            } catch (_: Exception) {
                runOnUiThread {
                    appendLine("JARVIS: Server AI belum terhubung. Atur backendUrl di MainActivity.kt dan deploy backend terlebih dahulu.")
                    status.text = "● BACKEND BELUM DIATUR"; animateOrb(false)
                }
            }
        }
    }

    // Aksi ini berjalan lokal di Android dan tidak membutuhkan AI API.
    private fun runLocalCommand(raw: String): Boolean {
        val message = raw.lowercase(Locale("id", "ID")).trim()
        val launchTargets = listOf(
            "whatsapp" to listOf("buka whatsapp", "open whatsapp"),
            "youtube" to listOf("buka youtube", "open youtube"),
            "kamera" to listOf("buka kamera", "buka camera", "open camera"),
            "pengaturan" to listOf("buka pengaturan", "buka settings", "open settings")
        )
        for ((target, phrases) in launchTargets) {
            if (phrases.any { message.contains(it) }) {
                return try {
                    when (target) {
                        "whatsapp" -> {
                            val launch = packageManager.getLaunchIntentForPackage("com.whatsapp")
                                ?: packageManager.getLaunchIntentForPackage("com.whatsapp.w4b")
                                ?: throw ActivityNotFoundException()
                            startActivity(launch)
                        }
                        "youtube" -> {
                            val launch = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                            startActivity(launch)
                        }
                        "kamera" -> startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
                        else -> startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                    }
                    respondLocal("Baik, saya membuka $target.")
                    true
                } catch (_: Exception) {
                    respondLocal("Maaf, aplikasi $target tidak dapat dibuka di perangkat ini.")
                    true
                }
            }
        }

        val alarmMatch = Regex("""(?:alarm|bangunkan saya|bangunkan aku).*?(\\d{1,2})[:.]?(\\d{2})?""").find(message)
        if (alarmMatch != null) {
            val hour = alarmMatch.groupValues[1].toIntOrNull()
            val minute = alarmMatch.groupValues[2].takeIf { it.isNotBlank() }?.toIntOrNull() ?: 0
            if (hour != null && hour in 0..23 && minute in 0..59) {
                return try {
                    val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                        putExtra(AlarmClock.EXTRA_HOUR, hour)
                        putExtra(AlarmClock.EXTRA_MINUTES, minute)
                        putExtra(AlarmClock.EXTRA_MESSAGE, "Alarm dari JARVIS")
                        putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                    }
                    startActivity(intent)
                    respondLocal("Saya menyiapkan alarm pukul %02d:%02d. Silakan konfirmasi di aplikasi Jam.".format(hour, minute))
                    true
                } catch (_: Exception) {
                    respondLocal("Maaf, aplikasi Jam tidak tersedia."); true
                }
            }
        }

        if (message.startsWith("pengingat ") || message.startsWith("ingatkan saya ")) {
            val title = raw.substringAfter(" ", raw).trim().ifBlank { "Pengingat dari JARVIS" }
            return try {
                val intent = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI).apply {
                    putExtra(CalendarContract.Events.TITLE, title)
                    putExtra(CalendarContract.Events.DESCRIPTION, "Dibuat melalui JARVIS AI")
                    putExtra(CalendarContract.Events.ALL_DAY, false)
                }
                startActivity(intent)
                respondLocal("Saya membuka kalender untuk membuat pengingat: $title. Silakan atur tanggal dan waktunya.")
                true
            } catch (_: Exception) {
                respondLocal("Aplikasi kalender tidak tersedia atau tidak dapat dibuka."); true
            }
        }
        return false
    }

    private fun respondLocal(reply: String) {
        appendLine("JARVIS: $reply")
        status.text = "● LOCAL ACTION COMPLETE"
        animateOrb(false)
        speak(reply)
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts?.language = Locale("id", "ID")
    }

    override fun onDestroy() {
        handsFree = false
        try { speechRecognizer?.destroy() } catch (_: Exception) {}
        tts?.stop(); tts?.shutdown(); executor.shutdownNow()
        super.onDestroy()
    }
}
