import express from "express";

const app = express();
app.use(express.json({ limit: "1mb" }));

const PORT = process.env.PORT || 3000;
const AI_API_KEY = process.env.AI_API_KEY;
const AI_API_URL = process.env.AI_API_URL || "https://api.openai.com/v1/responses";
const AI_MODEL = process.env.AI_MODEL || "gpt-4.1-mini";

app.get("/", (_req, res) => res.json({ status: "JARVIS backend online" }));

app.post("/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "Message is required" });
    if (!AI_API_KEY) return res.status(500).json({ error: "Server AI_API_KEY belum diatur" });

    const upstream = await fetch(AI_API_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${AI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: AI_MODEL,
        instructions: "Kamu adalah JARVIS, asisten AI yang ramah, cerdas, ringkas, dan menjawab dalam bahasa Indonesia kecuali diminta bahasa lain. Jangan mengaku bisa mengontrol perangkat jika tidak benar-benar memiliki akses.",
        input: message
      })
    });

    const data = await upstream.json();
    if (!upstream.ok) {
      return res.status(upstream.status).json({ error: data?.error?.message || "Penyedia AI mengembalikan kesalahan." });
    }

    let reply = data.output_text;
    if (!reply && Array.isArray(data.output)) {
      reply = data.output.flatMap(item => item.content || [])
        .filter(item => item.type === "output_text")
        .map(item => item.text).join("\\n");
    }
    return res.json({ reply: reply || "Maaf, saya belum mendapat jawaban." });
  } catch (error) {
    return res.status(500).json({ error: "Kesalahan server", detail: String(error) });
  }
});

app.listen(PORT, () => console.log(`JARVIS backend listening on ${PORT}`));
